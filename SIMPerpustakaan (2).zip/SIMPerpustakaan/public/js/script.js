// script.js

// Misalnya, menampilkan alert jika tombol diklik (contoh interaktif)
document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('button');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        console.log(`Tombol '${btn.innerText}' diklik.`);
      });
    });
  });
  