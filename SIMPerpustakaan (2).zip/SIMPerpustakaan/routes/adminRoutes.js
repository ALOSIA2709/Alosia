// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { ensureAuthenticated } = require('../middleware/auth');
console.log('adminController:', adminController);
// Admin dashboard
router.get('/dashboard', ensureAuthenticated('admin'), adminController.dashboard);

// Tambah buku
router.get('/tambah-buku', ensureAuthenticated('admin'), adminController.formTambahBuku);
router.post('/tambah-buku', ensureAuthenticated('admin'), adminController.tambahBuku);


// (Opsional) Hapus & Edit buku — bisa kamu tambahkan nanti
 router.get('/edit-buku/:id', ensureAuthenticated('admin'), adminController.formEditBuku);
 router.post('/edit-buku/:id', ensureAuthenticated('admin'), adminController.editBuku);
 router.get('/hapus-buku/:id', ensureAuthenticated('admin'), adminController.hapusBuku);

 router.get('/requests', ensureAuthenticated('admin'), adminController.viewRequests);

 router.post('/requests/delete/:id', ensureAuthenticated('admin'), adminController.deleteRequest);
 router.post('/requests/accept/:id', ensureAuthenticated('admin'), adminController.acceptRequest);
 
module.exports = router;
