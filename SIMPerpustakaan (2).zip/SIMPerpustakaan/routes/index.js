const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.get('/', (req, res) => {
  res.redirect('/login');
});

router.get('/login', (req, res) => {
  res.render('login');
});

router.get('/register', (req, res) => {
    res.render('register'); // Tampilkan form registrasi
  });
  
  
  

router.post('/login', authController.login);
router.get('/logout', authController.logout);
router.post('/register', authController.register); // Proses registrasi

module.exports = router;
