// routes/userRoutes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { ensureAuthenticated } = require('../middleware/auth');

// Halaman beranda user
router.get('/home', ensureAuthenticated('user'), userController.home);

// Pinjam buku
router.post('/borrow/:id', ensureAuthenticated('user'), userController.borrowBook);
router.get('/borrow', ensureAuthenticated('user'), userController.borrowHistory);


router.get('/', (req, res) => {
    res.redirect('/user/home');
  });
router.get('/profile', ensureAuthenticated(), userController.profile);

router.get('/request', ensureAuthenticated('user'), userController.requestForm);
router.post('/request', ensureAuthenticated('user'), userController.requestBook);

  
module.exports = router;
