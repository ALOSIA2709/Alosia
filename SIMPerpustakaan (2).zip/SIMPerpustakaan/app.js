const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const path = require('path');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

// Load environment variables
dotenv.config();

const app = express();

// MongoDB Connection
const connectDB = require('./config/db');
connectDB();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

/// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session
app.use(session({
  secret: 'rahasiaPerpustakaan',
  resave: false,
  saveUninitialized: true
}));

// Middleware untuk session ke view
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});


// Routes
const indexRoutes = require('./routes/index');
const adminRoutes = require('./routes/adminRoutes');
const userRoutes = require('./routes/userRoutes');

app.use((req, res, next) => {
    console.log(`[DEBUG] ${req.method} ${req.url}`);
    next();
  });
  

app.use('/', indexRoutes);
app.use('/admin', adminRoutes);
app.use('/user', userRoutes);

// Default error handler
app.use((req, res) => {
  res.status(404).send('Halaman tidak ditemukan');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});

