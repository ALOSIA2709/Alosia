// seed.js
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/userModel');

dotenv.config();

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('✅ Terkoneksi ke MongoDB');

    // Hapus semua user lama
    await User.deleteMany();

    // Tambah user baru
    const users = [
      { username: 'admin', password: 'admin123', role: 'admin' },
      { username: 'user', password: 'user123', role: 'user' }
    ];

    for (const user of users) {
      try {
        const newUser = new User(user);
        await newUser.save();
        console.log(`✅ User ${user.username} berhasil dibuat.`);
      } catch (err) {
        console.error(`❌ Gagal buat user ${user.username}:`, err.message);
      }
    }

    mongoose.disconnect();
  })
  .catch(err => console.error('❌ Gagal konek MongoDB:', err.message));
