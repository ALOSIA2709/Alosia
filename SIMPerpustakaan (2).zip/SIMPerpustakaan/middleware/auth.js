// middleware/auth.js

function ensureAuthenticated(role) {
    return (req, res, next) => {
      if (req.session && req.session.user) {
        // Jika role cocok atau tidak dicek
        if (!role || req.session.user.role === role) {
          return next();
        }
        return res.status(403).send('❌ Akses ditolak: tidak punya izin.');
      }
      // Belum login
      res.redirect('/login');
    };
  }
  
  // Optional middleware jika ingin digunakan langsung
  function logout(req, res, next) {
    req.session.destroy(err => {
      if (err) return next(err);
      res.redirect('/login');
    });
  }
  
  module.exports = {
    ensureAuthenticated,
    logout
  };
  