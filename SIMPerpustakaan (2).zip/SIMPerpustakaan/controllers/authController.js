const User = require('../models/userModel');

const login = async (req, res) => {
  const { username, password, role } = req.body;

  try {
    const user = await User.findOne({ username, role });
    if (!user) return res.send('❌ User tidak ditemukan atau peran salah.');

    const isMatch = await user.matchPassword(password);
    if (!isMatch) return res.send('❌ Password salah.');

    req.session.user = {
      id: user._id,
      username: user.username,
      role: user.role
    };

    res.redirect(role === 'admin' ? '/admin/dashboard' : '/user/home');
  } catch (err) {
    console.error(err);
    res.send('❌ Terjadi kesalahan saat login.');
  }
};

const logout = (req, res) => {
  req.session.destroy(err => {
    if (err) return res.send('❌ Gagal logout.');
    res.redirect('/login');
  });
};

const register = async (req, res) => {
  const { username, password } = req.body;

  try {
    const existingUser = await User.findOne({ username });
    if (existingUser) return res.send('❌ Username sudah digunakan.');

    const newUser = new User({ username, password, role: 'user' });
    await newUser.save();

    req.session.user = {
      id: newUser._id,
      username: newUser.username,
      role: newUser.role
    };

    res.redirect('/user/home');
  } catch (err) {
    console.error(err);
    res.send('❌ Gagal registrasi.');
  }
};

module.exports = {
  login,
  logout,
  register
};
