const Book = require('../models/bookModel');

const dashboard = async (req, res) => {
  try {
    const books = await Book.find();
    res.render('admin/dashboard', { books });
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

// Ubah nama fungsi addBook jadi:
const tambahBuku = async (req, res) => {
    const { title, author, year, stock } = req.body;
    try {
      await Book.create({ title, author, year, stock });
      res.redirect('/admin/dashboard');
    } catch (err) {
      res.status(500).send('Failed to add book');
    }
  };
  


// Form tambah buku
const formTambahBuku = (req, res) => {
    res.render('admin/formTambahBuku'); // Pastikan file views/admin/formTambahBuku.ejs ada
  };
  
// Form edit buku
const formEditBuku = async (req, res) => {
    try {
      const book = await Book.findById(req.params.id);
      res.render('admin/formEditBuku', { book }); // Pastikan file views/admin/formEditBuku.ejs ada
    } catch (err) {
      res.status(500).send('Gagal menampilkan form edit');
    }
  };
  
  // Proses edit buku
const editBuku = async (req, res) => {  
    try {
      const { title, author, year, stock } = req.body;
      await Book.findByIdAndUpdate(req.params.id, { title, author, year, stock });
      res.redirect('/admin/dashboard');
    } catch (err) {
      res.status(500).send('Gagal mengedit buku');
    }
  };
  
  // Hapus buku
const hapusBuku = async (req, res) => {
    try {
      await Book.findByIdAndDelete(req.params.id);
      res.redirect('/admin/dashboard');
    } catch (err) {
      res.status(500).send('Gagal menghapus buku');
    }
  };    

const BookRequest = require('../models/bookRequestModel');

const viewRequests = async (req, res) => {
  try {
    const requests = await BookRequest.find().populate('user');
    res.render('admin/requests', { requests });
  } catch (err) {
    res.status(500).send('Gagal mengambil data request buku');
  }
};



// Hapus request
const deleteRequest = async (req, res) => {
  try {
    await BookRequest.findByIdAndDelete(req.params.id);
    res.redirect('/admin/requests');
  } catch (err) {
    res.status(500).send('Gagal menghapus request');
  }
};

// Terima request (tambahkan ke daftar buku)
const acceptRequest = async (req, res) => {
  try {
    const request = await BookRequest.findById(req.params.id);
    if (!request) return res.status(404).send('Request tidak ditemukan');

    // Tambah ke daftar buku
    await Book.create({
      title: request.title,
      author: request.author,
      stock: 1
    });

    // Hapus request
    await BookRequest.findByIdAndDelete(req.params.id);

    res.redirect('/admin/requests');
  } catch (err) {
    res.status(500).send('Gagal menerima request');
  }
};

  
module.exports = {
    dashboard,
    tambahBuku,
    formTambahBuku,
    formEditBuku,
    editBuku,
    hapusBuku,
    viewRequests,
    deleteRequest,
    acceptRequest


};
