const Book = require('../models/bookModel');
const Borrow = require('../models/borrowModels');
const BookRequest = require('../models/bookRequestModel');

const home = async (req, res) => {
    try {
      const books = await Book.find();
      res.render('user/home', {
        books,
        user: req.session.user // ini yang ditambahkan
      });
    } catch (err) {
      res.status(500).send('Server Error');
    }
  };
  

const borrowBook = async (req, res) => {
    try {
      const bookId = req.params.id;
      const userId = req.session.user._id;
  
      // Kurangi stok buku
      const book = await Book.findById(bookId);
      if (book.stock < 1) {
        return res.status(400).send('Stok buku habis');
      }
  
      book.stock -= 1;
      await book.save();
  
      // Simpan data peminjaman
      await Borrow.create({ user: userId, book: bookId });
  
      res.redirect('/user/home');
    } catch (err) {
      res.status(500).send('Gagal meminjam buku');
    }
  };
// Form untuk request buku
const requestForm = (req, res) => {
  res.render('user/request');
};

// Proses request buku
const requestBook = async (req, res) => {
  try {
    await BookRequest.create({
      title: req.body.title,
      author: req.body.author,
      user: req.session.user._id
    });
    res.redirect('/user/home');
  } catch (err) {
    res.status(500).send('Gagal mengirim request buku');
  }
};

const profile = (req, res) => {
    const user = req.session.user;
    res.render('user/profile', { user });
  };

  const borrowHistory = async (req, res) => {
    try {
      console.log('Masuk ke controller borrowHistory');
      const userId = req.session.user._id;
      const borrows = await Borrow.find({ user: userId }).populate('book');
      res.render('user/pinjam', { borrows });
    } catch (err) {
      console.error(err);
      res.status(500).send('Gagal mengambil data peminjaman');
    }
};

  

module.exports = {
  home,
  borrowBook,
  profile,
  requestForm,
  requestBook,
  borrowHistory
};
